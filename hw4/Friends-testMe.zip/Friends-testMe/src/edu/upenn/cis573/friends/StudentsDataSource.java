package edu.upenn.cis573.friends;
import java.util.List;

/*
 * This class only exists purely so that our code will compile.
 * You will create mock objects that extend this class in Step 2.
 */

public class StudentsDataSource implements DataSource {

	public List<String> get(String arg) {
		return null;
	}

}
