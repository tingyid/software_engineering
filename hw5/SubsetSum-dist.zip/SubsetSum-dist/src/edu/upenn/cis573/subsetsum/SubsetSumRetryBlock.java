package edu.upenn.cis573.subsetsum;

public class SubsetSumRetryBlock extends SubsetSumSolver {

	/*
	 * Use a Retry Block to implement this method.
	 * Use the SubsetSumSolverDP.solve method in your Retry Block.
	 * Use the acceptance test in SubsetSumSolver
	 */	
	public boolean[] solve(int[] A, int target) throws ValidSolutionNotFoundException {

		// IMPLEMENT THIS METHOD!
				
		throw new ValidSolutionNotFoundException();

	}
	
	/*
	 * This is the method that you need to implement as part of your Retry Block.
	 */
    protected void shuffle(int A[]) {

    	// IMPLEMENT THIS METHOD!
    	
    }

}
