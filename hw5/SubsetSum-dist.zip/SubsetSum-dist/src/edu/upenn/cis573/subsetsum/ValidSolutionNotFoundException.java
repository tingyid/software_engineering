package edu.upenn.cis573.subsetsum;

public class ValidSolutionNotFoundException extends Exception {

}
