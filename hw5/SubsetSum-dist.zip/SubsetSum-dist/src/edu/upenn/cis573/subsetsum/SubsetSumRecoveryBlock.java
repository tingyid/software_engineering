package edu.upenn.cis573.subsetsum;

public class SubsetSumRecoveryBlock extends SubsetSumSolver {

	/*
	 * Use a Recovery Block to implement this method.
	 * Use the SubsetSumSolverBF.solve and SubsetSumSolverDP.solve methods in your Recovery Block.
	 * Use the acceptance test you wrote in SubsetSumSolver
	 */	
	public boolean[] solve(int[] A, int target) throws ValidSolutionNotFoundException {

		// IMPLEMENT THIS METHOD!
				
		throw new ValidSolutionNotFoundException();

	}

}
